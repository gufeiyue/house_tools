# coding:utf-8
import sys
reload(sys)
sys.setdefaultencoding('utf-8')

from flask import render_template, request, redirect, url_for, flash, jsonify
from . import tax
import re

@tax.route('/commercial_loan', methods=['GET', 'POST'])
def commercial_loan():
    return render_template('tax/commercial_loan.html')


@tax.route('/provident_fund_loan', methods=['GET', 'POST'])
def provident_fund_loan():
    return render_template('tax/provident_fund_loan.html')


@tax.route('/combination_loan', methods=['GET', 'POST'])
def combination_loan():
    return render_template('tax/combination_loan.html')


@tax.route('/commercial_calc', methods=['GET', 'POST'])
def commercial_calc():
    # loan_type = request.form.get('loan_type')
    loan_total = request.form.get('loan_total')
    loan_year = request.form.get('loan_year')
    loan_rate = request.form.get('loan_rate')
    # select2 = request.form.get('select2')
    # print loan_type
    print loan_total
    print loan_year
    print loan_rate
    loan_year = int(re.sub("\D", "", loan_year))
    loan_rate = re.findall(r"\((.*)\%\)", loan_rate)
    print type(loan_year)
    print loan_rate
    # print select2

    # return render_template('tax/loan_result.html')


@tax.route('/provident_fund_clac', methods=['GET', 'POST'])
def provident_fund_clac():
    return render_template('tax/loan_result.html')


@tax.route('/combination_clac', methods=['GET', 'POST'])
def combination_clac():
    return render_template('tax/loan_result.html')





@tax.route('/purchase', methods=['GET', 'POST'])
def purchase():
    return render_template('tax/purchase.html')


@tax.route('/test4', methods=['GET', 'POST'])
def test4():
    return render_template('tax/test4.html')


@tax.route('/tax_cal', methods=['GET', 'POST'])
def tax_cal():
    buyerfirsthouse = request.form.get('buyerfirsthouse')
    selleronlyhouse = request.form.get('selleronlyhouse')
    house_total = request.form.get('house_total')
    house_org = request.form.get('house_org')
    house_area = request.form.get('house_area')
    house_year = request.form.get('house_year')
    # house_type = request.form.get('house_type')
    house_location = request.form.get('house_location')


    buyerfirsthouse = str(buyerfirsthouse)
    selleronlyhouse = str(selleronlyhouse)
    house_area = float(house_area)
    house_total = float(house_total) * 10000
    house_org = float(house_org) * 10000
    house_year = int(house_year)
    house_location = str(house_location)
    # 内环以内:0
    # 内外环之间:1
    # 外环仕外:2

    if house_area > 140:
        house_type = 'non_ordinary'
    else:
        if house_total < 4500000 and house_location == '0':
            house_type = 'ordinary'
        elif house_total < 3100000 and house_location == '1':
            house_type = 'ordinary'
        elif house_total < 2300000 and house_location == '2':
            house_type = 'ordinary'
        else:
            house_type = 'non_ordinary'

    # house_type = str(house_type)

    if buyerfirsthouse == 'on':
        buyerfirsthouse = '0'
    else:
        buyerfirsthouse = '1'

    if selleronlyhouse == 'on':
        selleronlyhouse = '0'
    else:
        selleronlyhouse = '1'

    print "buyerfirsthouse: " + str(buyerfirsthouse)
    print "selleronlyhouse: " + str(selleronlyhouse)
    print "house_area: " + str(house_area)
    print "house_total: " + str(house_total)
    print "house_org: " + str(house_org)
    print "house_year: " + str(house_year)
    print "house_type: " + str(house_type)
    print "house_location: " + str(house_location)
    # house_type:0 普通
    # buyerfirsthouse:0 买唯一
    # selleronlyhouse:0 卖唯一

    income_tax = personal_income_tax(house_type, house_year, house_total, house_org, selleronlyhouse)
    total_personal_income_tax = int(income_tax[0])
    margin_personal_income_tax = int(income_tax[1])
    total_vat = int(vat(house_type, house_year, house_total, house_org))
    total_deed_tax = int(deed_tax(buyerfirsthouse, house_total, house_area))

    # if total_personal_income_tax > margin_personal_income_tax:
    #     personal_tax = margin_personal_income_tax
    # else:
    #     personal_tax = total_personal_income_tax

    personal_tax = total_personal_income_tax

    seller_total = personal_tax + total_vat
    buyer_total = total_deed_tax

    print income_tax
    print total_personal_income_tax
    print margin_personal_income_tax
    print total_vat
    print total_deed_tax

    all_tax = seller_total + buyer_total



    return render_template('tax/tax_result.html', total_vat=total_vat, total_deed_tax=total_deed_tax,
                           seller_total=seller_total, buyer_total=buyer_total, all_tax=all_tax, personal_tax=personal_tax)


#个人所得税
def personal_income_tax(house_type, house_year, house_total, house_org, selleronlyhouse):

    income_tax = []
    # if house_year == 5 and selleronlyhouse == '0':
    #     #满5年且卖方唯一住房，个人所得税为0
    #     total_personal_income_tax = 0
    #     margin_personal_income_tax = 0
    # else:
    #     if house_type == 'ordinary':
    #         total_personal_income_tax = house_total * 0.01
    #         margin_personal_income_tax = (house_total - house_org) * 0.2
    #     else:
    #         #房产证不满5年，个人所得税为（房屋现总价-房屋原价）*20%
    #         total_personal_income_tax = house_total * 0.02
    #         margin_personal_income_tax = (house_total - house_org) * 0.2

    if house_type == 'ordinary':
        if house_year == 5:
            if selleronlyhouse == '0':
                # 满5年且卖方唯一住房，个人所得税为0
                total_personal_income_tax = 0
                margin_personal_income_tax = 0
            else:
                # 满5年但非卖方唯一住房，个人所得税为（房屋现总价-房屋原价）*20%
                total_personal_income_tax = house_total * 0.01
                margin_personal_income_tax = (house_total - house_org) * 0.2
        else:
            #房产证不满5年，个人所得税为（房屋现总价-房屋原价）*20%
            total_personal_income_tax = house_total * 0.01
            margin_personal_income_tax = (house_total - house_org) * 0.2
    else:
        if house_year == 5:
            if selleronlyhouse == '0':
                # 满5年且卖方唯一住房，个人所得税为0
                total_personal_income_tax = 0
                margin_personal_income_tax = 0
            else:
                # 满5年但非卖方唯一住房，个人所得税为（房屋现总价-房屋原价）*20%
                total_personal_income_tax = house_total * 0.02
                margin_personal_income_tax = (house_total - house_org) * 0.2
        else:
            # 房产证不满5年，个人所得税为（房屋现总价-房屋原价）*20%
            total_personal_income_tax = house_total * 0.02
            margin_personal_income_tax = (house_total - house_org) * 0.2

    income_tax.append(total_personal_income_tax)
    income_tax.append(margin_personal_income_tax)

    return income_tax



#卖方 增值税
#注：过去征税房价是含税价，营改增后是不含税价，税率维持5%不变，实际税收负担降为4.76%。
def vat(house_type, house_year, house_total, house_org):
    if house_type == 'ordinary':
        if house_year == 0:
            vat_reason = '普通住宅购房不满2年，增值税为总房价的5.6%'
            print vat_reason
            total_vat = house_total * 0.056 / 1.05
        else:
            vat_reason = '普通住宅购房满2年，增值税为0'
            print vat_reason
            total_vat = 0
    else:
        if house_year == 0:
            vat_reason = '非普通住宅购房不满2年，增值税为总房价的5.6%'
            print vat_reason
            total_vat = house_total * 0.056 / 1.05
        else:
            vat_reason = '非普通住宅购房满2年，增值税为（房屋现总价 - 房屋原价）* 5.6%'
            print vat_reason
            total_vat = (house_total - house_org ) * 0.056 / 1.05

    return total_vat


#买方交: 契税：
def deed_tax(buyerfirsthouse, house_total, house_area):
    if house_area > 90:
        if buyerfirsthouse == '0':
            deed_tax_reason = '首次购房且>90㎡，契税为总房价的1.5%'
            total_deed_tax = house_total * 0.015
        else:
            deed_tax_reason = '非首次购买，契税为总房价的3%'
            total_deed_tax = house_total * 0.03
    else:
        if buyerfirsthouse == '0':
            deed_tax_reason = '首次购房且面积≤90㎡，契税为总房价的1%'
            total_deed_tax = house_total * 0.01
        else:
            deed_tax_reason = '非首次购买，契税为总房价的3%'
            total_deed_tax = house_total * 0.03

    return total_deed_tax



@tax.route('/tax', methods=['GET', 'POST'])
def tax():
    return render_template('tax/tax.html')



